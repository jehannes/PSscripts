Derivative of MultiSorter_v4,Testscript4,Testscript5,Testscript6, and Testscript7
MultisorterV4 was experimental development of v3 itself a development of earlier versions and ultimately DownloadsSorter

this being dev version 1 of the FileFolderSorter (FFS)