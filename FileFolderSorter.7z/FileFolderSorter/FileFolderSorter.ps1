#checkscript hashes (sha512) throw error and terminate if wrong

#get inputs from files

#call FolderCheckerCreator
#call CopyFinderDeleter
#call Sorter

#write log