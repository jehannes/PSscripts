#change from testscript4:
#use input to get folder
#add date limit for deleter
#use input for date limit